
<section>
   <div class="img-container porter_partner_home_img signup_content_head">
      <div class="col-md-6">
         <div class="box box-color box-bordered signup_content">
            <h2 class="heading_kyc">
               <strong class="heading_log">Sign Up</strong>
            </h2>
            <center><span id="signup-error" class="signup_error"></span></center>
            <div class="box-content nopadding">
               <div class="tab-content padding tab-content-inline tab-content-bottom">
                  <div class="tab-pane active" id="profile">
                     <div class="login-body my_login_body">
                        <form action="<?php echo base_url('login/csignupAction') ?>" method="POST" id="customer-signup-form" autocomplete="anyrandomstring" class="form-horizontal">
                           <div class="myform_cont">
                              <div class="div_block col-md-12">
                                 <label for="cust_name"><b>Full Name</b></label><span id="cust_name-error" class="signup_error"></span>
                                 <input type="text" placeholder="Enter Full Name" class="form-control cust_name" name="cust_name" required>
                              </div>
                              <div class="div_block col-md-6">
                                 <label for="cust_mobile_no"><b>Mobile Number</b></label><span id="mobile-error" class="signup_error"></span>
                                 <input type="number" placeholder="Enter Contact" class="form-control cust_mobile_no" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="10" name="cust_mobile_no" required> 
                              </div>
                              <div class="div_block col-md-6">  
                                 <label for="cust_email"><b>Email</b></label>  
                                 <input type="email" placeholder="Enter Eamil" class="form-control" name="cust_email"  required>
                              </div>
                              <div class="div_block col-md-6">
                                 <label for="cust_password"><b>Password(6 Characters Minimum)</b></label>
                                 <input type="password" placeholder="Enter Password" class="form-control password"  minlength="6" maxlength="10" name="cust_password" required>
                              </div>
                              <div class="div_block col-md-6">
                                 <label for="cnf_password"><b>Confirm Password</b></label><span id="cnfpassword-error" class="signup_error"></span>
                                 <input type="password" placeholder="Enter Confirm Password" class="form-control cnf_password"   minlength="6" maxlength="10" name="cnf_password" required>
                              </div>
                              <div class="clearfix"></div>
                              <input  type="submit" value="Submit" class="form_sub" id="btn-submitt">
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-md-6 img_side">
         <img style="padding:100px" src="<?php echo base_url('assets/customer_theme/img/signup.png') ?>" class="sign_img_div">
      </div>
      <div class="clearfix"></div>
   </div>
</section>
<script type="text/javascript"> 
   $(document).ready(function() {
      $(".cust_name").change(function() {
    if ( $(this).val().match('^([A-Za-z]+ )+[A-Za-z]+$|^[A-Za-z]+$') ) {
        return true;    
    } else {
        $('#cust_name-error').html("Enter a Valid Name!"); 
            setTimeout(function(){
                $(".signup_error").html('');
            }, 2000);
                       
                    $(".cust_name").val('');    
                    $(".cust_name").focus();     
    }
   });
   
   
      $(".cnf_password").change(function () {    
                var password = $(".password").val();    
    var cnf_password = $(".cnf_password").val();
                if (password == cnf_password) {    
                    return true;    
                } else {    
        $('#cnfpassword-error').html("Confirmed Password Does Not Matches To The Entered Password!"); 
            setTimeout(function(){
                $(".signup_error").html('');
            }, 2000);
                       
                    $(".cnf_password").val('');    
                    $(".cnf_password").focus();     
                }       
            }); 
   $(".cust_mobile_no").change(function () {    
                    var cust_mobile_no = $(".cust_mobile_no").val(); 
    if (cust_mobile_no.length ==  10) {    
                    return true;    
                } else {   
                    $("#mobile-error").html("Enter Valid Mobile Number");       
                     setTimeout(function(){
                $(".signup_error").html('');
            }, 2000);  
                    $(".cust_mobile_no").val('');     
                    $(".cust_mobile_no").focus();           
                }       
            }); 
   
   $('#customer-signup-form').submit(function(event) {
    event.preventDefault(); 
    var formData = new FormData(this);
   $.ajax({
      type:'POST',
      url:$(this).attr('action'),
      data:formData,
      cache:false,
      contentType: false, 
      processData: false,
    
      success:function(res){
        
        if(res.trim() == 'true'){
        
          
    
   window.location.href = "<?php echo base_url('cdashboard');?>";
   
          toastr.success('Registered  Successfully..',{timeOut: 3000}); 
   
        } else {
   $('#signup-error').html(res);
        setTimeout(function(){
                $(".signup_error").html('');
            }, 2000);   
        
        }
   
      } 
   
    });
   });
   
   
   });
   
   
   
</script>