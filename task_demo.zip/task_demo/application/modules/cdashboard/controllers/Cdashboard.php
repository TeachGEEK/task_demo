<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cdashboard extends MX_Controller 
{
	public function __Construct()
   	{
      parent::__Construct();
	  if(empty($this->session->userdata('username'))){
	        redirect(base_url('login')); 
	    }
	  $this->load->model("Cdashboard_model");
    }
	
	public function index()
	{
		

		$this->load->homepage('cdashboard' , '' ,TRUE);
	}
	public function task2()
	{
		

		$this->load->homepage('missing_number' , '' ,TRUE);
	}
	public function task3()
	{
		$data['menu'] = $this->common->getData('menuname,menuid','menus',array('submenu_id' => '0'),'menuid'); 
		$data['submenu'] = $this->common->getData('menuname,submenu_id,menuid','menus',array('submenu_id !=' => '0','sub_submenu_id' => '0'),'menuid'); 
		$data['subsubmenu'] = $this->common->getData('menuname,submenu_id,sub_submenu_id','menus',array('sub_submenu_id !=' => '0'),'menuid'); 

		$this->load->homepage('dynamic_menu' , $data ,TRUE);
	}

	public function missing_number()
	{
		 
		$number=$this->input->post('numbers');
		if(!empty($number)){

				$number_array = explode(",", $number);
				$new_array = range($number_array[0],max($number_array));
				$result= array_diff($new_array, $number_array);
				$result = implode(" ",$result);
				if($result!=""){echo $result;}else{echo "No number missing in this series";}
				
			}

		
	}
	

	
}
?>
