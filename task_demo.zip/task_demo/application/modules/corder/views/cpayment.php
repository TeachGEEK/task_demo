	 <?php  $order_id = $this->input->get('order_id');?>
	<div class="img-container porter_partner_home_img cpayment_address_head">
		<div class="img_left_order">
			<div class="box box-color box-bordered signup_content_pay">
				<h2 class="heading_kyc"><strong class="heading_log">Payment</strong></h2>
				<div class="box-content nopadding"><hr>
					<div class="tab-content padding tab-content-inline tab-content-bottom">
						<div class="tab-pane active" id="profile">
							<div class="login-body my_login_body">
								<div class="container myform_cont cust_form_sign1">
									
									<div class="col-md-12">
										<div class="order_summery">
											<div class="box box-color box-bordered">
												<div class="box-title my_box_head">
													<h3><i class="fa fa-bar-chart" aria-hidden="true"></i>Order Summary</h3>
												</div>
												<div class="box-content">
													<div class="row">
													    <div class="col-md-5">
														 <h4><b>Total amount</b></h4>
													    </div>
													    <div class="col-md-2">
														 :
													    </div>
													    <div class="col-md-5">
														 <h4><b> ₹ &nbsp;<?php echo  number_format((float)$payment_info->total_amount, 2, '.', '');  ?></b></h4>
													    </div>
												    </div>
												</div>
											</div>
										</div>
									</div>
									<div class="clearfix"></div>
									<div class="col-md-12 payment_head_bg">
									    
										<form action="<?php echo base_url('corder/paymentAction?=') ?><?php echo $order_id; ?>" method="POST" id="customer-order-form" class="form-horizontal">
											<div class="col-md-12">
												
											    <input type="button" id="hidden_div" value="Pay Online" class="form_sub buy_now " data-amount="<?php echo $payment_info->total_amount ; ?>" data-order-id="<?php echo $order_id; ?>" >
                                                 <input type="submit" id="hidden_div1" value="Place Order"  style="display:none;" class="form_sub  ">
									
										
											
											</div>
											
											
										</form>
									</div>
									 
								   </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script type="text/javascript"> 
   $(document).ready(function() {
   $('#customer-order-form').submit(function(event) {
    event.preventDefault(); 
    
    var formData = new FormData(this);
   
    $.ajax({
      type:'POST',
      url:$(this).attr('action'),
      data:formData,
      cache:false,
      contentType: false, 
      processData: false,
     
      success:function(res){
        
        if(res.trim() == 'true'){
        
       window.location.href = "/adminpanel/corderhistory"; 
       toastr.success('Ordered Placed Successfully..',{timeOut: 3000}); 
   
        } else {
   
          setTimeout(function() {
            toastr.error('Server error try again..',{timeOut: 2000});
          },500);
        
        }
   
      }
    });
   });
   
   
   });
 
    

var SITEURL = "<?php echo base_url() ?>";

$('body').on('click', '.buy_now', function(e){

	var totalAmount = $(this).attr("data-amount");
	var order_id =  $(this).attr("data-order-id");
	
	var options = {
	"key": "rzp_test_blitId6jEzyeHZ",
	"amount": (totalAmount*100), // 2000 paise = INR 20
	"name": "Task Demo",
	"description": "Payment",
	"image": "https://cdn0.iconfinder.com/data/icons/fuel-energy-vol-12/600/Drop-oil-fuel-liquid-droplet-gasoline-liquid-512.png",
	"handler": function (response){

	$.ajax({
	url: SITEURL + 'corder/razorPaySuccess',
	type: 'post',
	dataType: 'json',
	data: {
		razorpay_payment_id: response.razorpay_payment_id , 
		totalAmount : totalAmount ,
		order_id : order_id,
	}, 
	success: function (msg) {
		window.location.href = SITEURL + 'corder/thankyou';
	}
});
},
"theme": {
"color": "#5e0be0"
}
};
var rzp1 = new Razorpay(options);
rzp1.open();
e.preventDefault();
});

   
</script>