<?php

$config = array(
             	'user_valid_profile' => array(
                                array(
                                	'field'=>'fname',
                                	'label'=>'First Name',
                                	'rules'=>'trim|xss_clean'
                                ),
								array(
                                	'field'=>'lname',
                                	'label'=>'Last Name',
                                	'rules'=>'trim|xss_clean'
                                ),
								array(
                                    'field'=>'address',
                                    'label'=>'Address',
                                    'rules'=>'trim|xss_clean'
                                ),
								array(
                                	'field'=>'pin_code',
                                	'label'=>'Pin Code',
                                	'rules'=>'trim|xss_clean|max_length[6]'
                                ))
			   );
			   
?>