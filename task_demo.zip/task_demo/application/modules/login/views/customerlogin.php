<style>
.signup_error
{
	color:#FF0000; 
	padding-left:15px;
}  
</style>
<section>
  <div class="img-container porter_partner_home_img">
    <div class="col-md-6 box_side">
        <div class="box box-color box-bordered signin_content">
           <h2 class="heading_kyc">
               <strong class="heading_log">Sign In</strong>
           </h2>
            <center><span id="signup-error" class="signup_error"></span></center>
           </ul>
        <div class="tab-content padding tab-content-inline tab-content-bottom">
          <div class="tab-pane active" id="profile">
           <div class="login-body my_login_body">
             <form action="<?php echo base_url('login/cloginAction') ?>" method="POST" id="customer-signin-form" class="form-horizontal">
            <div>
                <div class="div_block">
                <label for="cust_email"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" class="form-control" name="cust_email" required>
                </div>
                <div class="div_block">
                <label for="cust_password"><b>Password</b></label>
                <input type="password" placeholder="Enter Password"  class="form-control" name="cust_password" required>
                </div>
                <div class="clearfix"></div>
                 <div>
                <a href="#" data-toggle="modal" data-target="#myModal">Forget Password?</a>
                </div>
                <input type="submit" value="Sign in" id="btn-submitt" class=" form_sub"><br>
                <a href="#" onclick="window.location.href='<?php echo base_url('login/customersignup');?>'">Register Your New Account?</a>
               
          </div>
          </form>
        </div>
      </div>
    </div>
    </div>
    </div>
    </div>
    <div class="col-md-6 box_side .d-sm-none .d-md-block img_side">
      <img style="padding:100px;" src="<?php echo base_url('assets/customer_theme/img/signup.png') ?>"  class="signup_img">
    </div>
    
    
    <div class="clearfix"></div>
    <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <form action="<?php echo base_url('login/send') ?>" method="POST" id="send-mail" class="form-horizontal">
            
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Forget Password</h4>
		  <center><span id="password-error" class="signup_error"></span></center>

        </div>
        <div class="modal-body">
          
               <div class="div_block">
                <label for="cust_email"><b>Enter Email Address</b></label>
                <input type="text" placeholder="Enter Username" class="form-control" name="cust_email" required>
                </div>
                <input type="submit" class="form_sub" value="Submit" >
         
        </div>
        <div class="modal-footer">
          <button type="button" class="form_sub" data-dismiss="modal">Close</button>
        </div>
      </div>
     </form>
    </div>
  </div>
  
    </div>
</section>
<script type="text/javascript"> 
   $(document).ready(function() {
    $('#customer-signin-form').submit(function(event) {
    event.preventDefault(); 
    var formData = new FormData(this);
	$.ajax({
      type:'POST',
      url:$(this).attr('action'),
      data:formData,
      cache:false,
      contentType: false, 
      processData: false,
      success:function(res){
        if(res.trim() == 'true'){
        window.location.href = "<?php echo base_url('cdashboard');?>";
			toastr.success('Logged In Successfully..',{timeOut: 3000});
		} else {

        
        $('#signup-error').html(res);
        setTimeout(function(){
                $(".signup_error").html('');
            }, 2000);  
        }

      }
    });
});
	
	
	
	$('#send-mail').submit(function(event) {
		
    event.preventDefault(); 
    var formData = new FormData(this);
	$.ajax({
      type:'POST',
      url:$(this).attr('action'),
      data:formData,
      cache:false,
      contentType: false, 
      processData: false,
	  
	 
	  
      success:function(res){
		 
        if(res.trim() == 'true'){
        window.location.href = "<?php echo base_url('login');?>";
			toastr.success('Password Email Reset Link Sent Successfully',{timeOut: 3000});
		} else {

          $('#password-error').html(res);
          $('#password-error').html(res);
        setTimeout(function(){
                $(".signup_error").html('');
            }, 2000);  
        
        }

      }
    });
});
	
   
  
   
   
   });
   
   
    
   
   
</script>