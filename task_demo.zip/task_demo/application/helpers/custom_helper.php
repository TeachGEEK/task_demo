<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


function expired($date)
{ 
  $d = date('Y-m-d',strtotime($date));
  $date1 = date_create(date('Y-m-d'));
  $date2 = date_create($d);
  $diff  = date_diff($date1,$date2);

  // echo '<pre>';
  // print_r($diff);
  return $diff->format('%r%a day');
}

function monthDiff($d1,$d2)
{ 
  $date1 = date('m',strtotime($d1));
  $date2 = date('m',strtotime($d2));
  $diff  = intval(($date2-$date1)+1);

  // echo '<pre>';
  // print_r($diff->m);
  return $diff;
}

function monthDiffDate($timestamp, $months){
  $day_current_date            = date('d', $timestamp);
  $first_date_of_current_month = date('01-m-Y', $timestamp);
  // 't' gives last day of month, which is equal to no of days
  $days_in_next_month          = date('t',  strtotime("+".$months." months", strtotime($first_date_of_current_month)));

  $days_to_substract = 0;
  if($day_current_date > $days_in_next_month)
       $days_to_substract = $day_current_date - $days_in_next_month;

  $php_date_after_months   = strtotime("+".$months." months", $timestamp);
  $exact_date_after_months = strtotime("-".$days_to_substract." days", $php_date_after_months);

  return date('Y-m-d',($exact_date_after_months));
  }

function status($arg1,$arg2)
{
  if(($arg1 == 'MPaused') && ($arg2 == 1)){
    return '<span style="font-size:12px;color:red;">(Paused)</span>';
  } elseif ($arg1 == 'EPaused' && ($arg2 == 2)) {
    return '<span style="font-size:12px;color:red;">(Paused)</span>';
  } elseif ($arg1 == 'MEPaused') {
    return '<span style="font-size:12px;color:red;">(Paused)</span>';
  } elseif($arg1 == 'Pending') {
    return '<span style="font-size:12px;color:blue;">(NO)</span>';
  } else {
    return '';
  }

}

function dateCal($givendate,$day=0,$mth=0,$yr=0) {
  $cd = strtotime($givendate);
  $newdate = date('Y-m-d', mktime(date('h',$cd),
  date('i',$cd), date('s',$cd), date('m',$cd)+$mth,
  date('d',$cd)+$day, date('Y',$cd)+$yr));
  return $newdate;
}

function nextMonth($givendate,$day=0,$mth=0,$yr=0) {
  $d = explode('-',$givendate);

  if(intval($d[1]) > 10){
    return $d[0].'-'.intval($d[1]+1).'-01';
  } else {
    return $d[0].'-0'.intval($d[1]+1).'-01';
  }
}

function dateDiff($day) {
  return date('Y-m-d',strtotime("-".$day." day"));  
}

function set_message($class, $content, $flashdata = true){
  $ci =& get_instance();
  $ci->load->library('session');
  
  $message = array('class' => $class, "content" => $content);
  if ( ! $flashdata ) {
      $method = $ci->router->method;
      $ci->session->set_userdata("{$method}_message", $message);
  }
  else {
      $ci->session->set_flashdata("message", $message);
  }       
}

function thumb($src, $width, $height, $image_thumb = '') {
  // Get the CodeIgniter super object
  $CI = &get_instance();

  // LOAD LIBRARY
  $CI->load->library('image_lib');
  // CONFIGURE IMAGE LIBRARY
  $config['image_library']   = 'gd2';
  $config['source_image']    = $src;
  $config['new_image']       = $image_thumb;
  $config['maintain_ratio']  = true;
  // $config['quality']         = 60;
  // $config['create_thumb']    = true;
  $config['thumb_marker']    = '_thumb';
  $config['width']           = $width;
  $config['height']          = $height;
  $CI->image_lib->initialize($config);
  $CI->image_lib->resize();
  $CI->image_lib->clear();
  // get our image attributes
  // list($original_width, $original_height, $file_type, $attr) = getimagesize($image_thumb);
  // // set our cropping limits.
  // $crop_x = ($original_width / 2) - ($width / 2);
  // $crop_y = ($original_height / 2) - ($height / 2);
  
  // // initialize our configuration for cropping
  // $config['source_image'] = $image_thumb;
  // $config['new_image'] = $image_thumb;
  // $config['x_axis'] = $crop_x;
  // $config['y_axis'] = $crop_y;
  // $config['maintain_ratio'] = FALSE;
  // $CI->image_lib->initialize($config);
  // $CI->image_lib->crop();
  // $CI->image_lib->clear();

  return basename($image_thumb);
}

function myEncrypt($msg,$key='')
{
  $CI = &get_instance();
  if(empty($key)){
      return $CI->encrypt->encode($msg);     
  } else {
      return $CI->encrypt->encode($msg,$key);     
  }
}

function myDecrypt($msg,$key='')
{
  $CI = &get_instance();
  if(empty($key)){
      return $CI->encrypt->decode($msg);     
  } else {
      return $CI->encrypt->decode($msg,$key);     
  }
}

function randValue()
{
  return str_pad(rand(0,9999),5, "1", STR_PAD_LEFT);
}

function array_recursive($ary)  {
  $lst = array();
  foreach( array_keys($ary) as $k ) {
    $v = $ary[$k];
    if (is_scalar($v)) {
        $lst[] = $v;
    } elseif (is_array($v)) {
        $lst = array_merge($lst,array_recursive($v));
    }
  }
  return array_values(array_unique($lst)); // used array_value function for rekey
}

function delete_directory($dirname) {
  if (is_dir($dirname))
    $dir_handle = opendir($dirname);
    if (!$dir_handle)
      return false;
    while($file = readdir($dir_handle)) {
      if ($file != "." && $file != "..") {
      if (!is_dir($dirname."/".$file))
        unlink($dirname."/".$file);
      else
        delete_directory($dirname.'/'.$file);
      }
   }
  closedir($dir_handle);
  rmdir($dirname);
  return true;
}

function pushNotification($token,$title,$message,$image='')
{
  $url = "https://fcm.googleapis.com/fcm/send";

  $serverKey = 'AAAAPve4plk:APA91bEnNe2jjJ-_CxBa4cIhVQ-3KJmAizk6KBYzTkmpHOV05RS3Wg9G68DESbgBYhxU4bieHo09NVp0JKw9b2n1Uo4jJFyXFIlmPAAfeD8_Pn4-XnXa_Xbce5xBI5nKzecOD6N1Nd9f';

  $token = gettype($token) == 'array' ? $token : array($token);
  
  $final_token =  array_chunk($token, 300);
      
  foreach ($final_token as $key => $tokens) {
      
    $notification = array(
                      'id'       => time(),
                      'title'    => $title,
                      'body'     => $message,
                      'image'    => $image,
                      'icon'     => 'ic_launcher',
                      'smallIcon'=> 'drawable/icon',
                      'sound'    => 'default',
                      'priority' => 'high',
                      'show_in_foreground' => true,
                      'vibrate'  => 1,
                      'light'    => true
                    );
        
    $arrayToSend = array('registration_ids' => $tokens,'notification' => $notification,'priority'=>'high','content_available' => true);

    $json = json_encode($arrayToSend);

    $string = str_replace("\\/", "/", $json);

    $headers = array();
    $headers[] = 'Content-Type: application/json';
    $headers[] = 'Authorization: key='. $serverKey;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $string);
    curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
    //Send the request
    $response = curl_exec($ch);
    //Close request
    if ($response === FALSE) {
        echo "";
    }
    curl_close($ch);
  }

}

?>