<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
   class Login extends MX_Controller 
   {
   	public function __Construct() 
      	{
           parent::__Construct();
           
           $this->load->library('email');
   		$this->load->model("Login_model");
       }
   	
   	public function index() 
   	{
   		if(!empty($this->session->userdata('username'))){
           redirect(base_url('cdashboard')); 
            }
         $this->load->homepage('customerlogin');
   	}
   	
   	public function customersignup()
   	{
   		
   		$this->load->homepage('customersignup','',TRUE);
   	}
   	public function cpasswordreset()
   	{
   		$token = $this->input->get('token');
   		 
   		$tokencomp = time();
   		$difference =  $tokencomp - $token;
   	
   		if($difference < 3600 )
   		{   
   			
   			$this->load->homepage('cpasswordreset','',TRUE);
   			
   		}
   		else
   		{ 
   			$this->load->homepage('linkexpire','',TRUE);
   		}
   					
   		
   	}
   	public function customerprofile()
   	{
   		
   		$this->load->homepage('customerprofile','',TRUE);
   	}
   	function send()
   	{
   		$cust_email = $this->input->post('cust_email');
   		if($this->Login_model->can_find_email($cust_email))  
           { 
   			$this->load->library('phpmailer_lib');
   			$mail = $this->phpmailer_lib->load();
   			$mail->isSMTP();
   			$mail->Host     = 'mail.bablabrothers.com';
   			$mail->SMTPAuth = true;
   			$mail->Username = 'noreply@bablabrothers.com';
   			$mail->Password = 'Mjw2DJ?w[f2h';
   			$mail->SMTPSecure = 'ssl';
   			$mail->Port     = 465;
   			$mail->setFrom('Annu@gmail.com', 'Annu Upadhyay');
   			$mail->addReplyTo('Annu@gmail.com', 'Annu Upadhyay');
   			$mail->addAddress($cust_email );
   			$mail->addCC('');
   			$mail->addBCC('');
   			$mail->Subject = 'Password Reset Link';
   			$mail->isHTML(true);
   			$link= base_url('login/cpasswordreset?email=').$cust_email.'&token='.time();
   			$mailContent = "<h1>Your Password Reset Link for Annu Upadhyay Is </h1>
   				<p>$link <br>Password Reset for your account in Annu Upadhyay has been requested . This link will expire in one hours .If not done by you , Kindly ignore this mail</p>";
   			$mail->Body = $mailContent;
   			if(!$mail->send())
   			{
   				echo 'Server Error , Please try again later.';
   				echo 'Mailer Error: ' . $mail->ErrorInfo;
   			}else
   			{
   				echo 'true';
   			} 
   		}
   		else
   		{
   			echo 'Invalid Username' ;
   		}
       }
       public function updatepasswordAction()  
   	{   
   	    $cust_email = $this->input->get('cust_email');
   	  
   		$cust_password = MD5($this->input->post('cust_password'));
   		$data = array(
   			   'cust_password'  	 		=> MD5($this->input->post('cust_password')),
   	        ); 
          			 
   		$this->common->update('customer',$data,array('cust_email' => $cust_email));
   		echo  "true";
   	}
   	public function csignupAction() 
   	{
   		
   		$cust_email = $this->input->post('cust_email');
   		$cust_name = $this->input->post('cust_name');
   		if(!empty($this->input->post('cust_name')))
   		{
   
   			$data = array(
   	            'cust_name'  	     => ucfirst($this->input->post('cust_name')),
   	            'cust_mobile_no'  	 => $this->input->post('cust_mobile_no'),
   	            'cust_email'  	     => $cust_email,
   	            'cust_password'  	 => md5($this->input->post('cust_password')), 
   	            
   				'created'  		     => date('Y-m-d H:i:s')
   	        );
   			if($this->Login_model->checkDuplicateEmail($cust_email))  
               { 
   			    $this->common->insert('customer',$data); 
   			    $result=$this->Login_model->read_user_information($cust_email);
   				$session_data = array(  
                             'username'     =>     $result[0]->cust_name,
   						  'user_id'     =>     $result[0]->cust_id,
   						  'user_email'     =>     $result[0]->cust_email,
   						  
                        );  
   				$this->session->set_userdata($session_data);  
   				$this->session->set_flashdata('customersignup', 'form submitted successfully'); 
   				echo 'true';
   			}
   			else
   			{
   				$link = base_url('login');
   				echo 'This Email is already registered with us, please <a herf='.$link.'>Click Here to Login</a>'; 
   			}
   		}
   		else
   		{
   			$this->session->set_flashdata('customersignup', 'Some Error Occured during Form Submmit');   
   		}
   
   	    
   	}
   	public function clogoutAction() 
   	{
   		session_destroy();
   		unset($session_data);
   		redirect(base_url() . 'login');
   	}
   	public function cloginAction()
   	{
   		
   		$cust_email    = $this->input->post('cust_email');  
           $cust_password = MD5($this->input->post('cust_password'));
           if($this->Login_model->can_find_email($cust_email))  
           {
   			if($this->Login_model->can_login($cust_email, $cust_password))  
   			{  
   				
   				$result=$this->Login_model->read_user_information($cust_email);
   				if(!empty($result)){
   				$session_data = array(  
   							  'username'     =>     $result[0]->cust_name,
   							  'user_id'     =>     $result[0]->cust_id,
   							  'user_email'     =>     $result[0]->cust_email,
   							  
   						 );  
   				$this->session->set_userdata($session_data);    
   				$this->session->set_flashdata('customersignup', 'Loggedin successfully');  
   				echo "true";
   				}
   				
   			} 
   			else
   			{
   				echo 'Incorrect Password '; 
   			}
   		}		
           else 
   		{  
   		    $link = base_url('login/customersignup');
               echo 'No such Email Found , <a href='.$link.' > Click Here To  Signup </a>'; 
              
           }
       }
   
   }
   ?>