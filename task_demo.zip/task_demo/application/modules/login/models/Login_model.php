<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function CheckAuth($email,$password){
       $this->db->select('*');
       $this->db->from('login');
       $this->db->where('email',$email);
       $this->db->where('password',MD5($password));
       return $this->db->get();
    }
    function can_login($cust_email, $cust_password)  
    {   
           
    $this->db->where('cust_email', $cust_email);  
        $this->db->where('cust_password', $cust_password);  
        $query = $this->db->get('customer');
        if($query->num_rows() > 0)  
        { 
        return true;
    }   
        else  
        {  
           return false;       
        }  
    } 
    function can_find_email($cust_email)  
    {   
           
    $this->db->where('cust_email', $cust_email);  
        $query = $this->db->get('customer');
        if($query->num_rows() > 0)  
        { 
        return true;
    }  
        else  
        {  
           return false;       
        }  
    }   
  public function read_user_information($cust_email)
  {
    $this->db->select('cust_id,cust_name,cust_email,kyc_status');
    $this->db->from('customer');
    $this->db->where('cust_email', $cust_email);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() == 1)
    {
      return $query->result();
    } 
    else 
    { 
      return false;
    }
  } 
  public function checkDuplicateEmail($cust_email)
  {

    $this->db->where('cust_email', $cust_email);
    $query = $this->db->get('customer');
    $count_row = $query->num_rows();
    if ($count_row > 0)
    {
      return FALSE;
    }
    else 
    {
      return TRUE;
    }
  }
}

/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */
/* Please DO NOT modify this information : */
