<div class="img-container porter_partner_home_img cpayment_address_head">
   <div class="">
      <div class="box box-color box-bordered order_history_head">
         <h2 class="heading_kyc"><strong class="heading_log"><i class="fa fa-home" aria-hidden="true"></i> Given Tasks</strong></h2>
         <hr class="hr_line">
         <div class="box-content nopadding top_box">
            </ul>
            <div class="tab-content padding tab-content-inline tab-content-bottom">
               <div class="tab-pane active" id="profile">
                  <div class="login-body my_login_body">
                     <div class="myform_cont container" style="padding-bottom:100px;">
                        <div class="col-md-12 customer_dash" >
                           <div class="col-md-6">
                              <div class="ya-card-cell1 card_height">
                                
                                    <div data-card-identifier="YourOrders" class="a-box ya-card--rich">
                                       <div class="a-box-inner">
                                          <div class="col-md-12">
                                             <p class="icon_p">
                                                <i class="dashicon" ><b>1</b></i>
                                             </p>
                                             <div class="col-md-12 col-sm-12 col-xs-12 dash_content">
                                                <h2 class="a-spacing-none ya-card__heading--rich a-text-normal">
                                                   Task1
                                                </h2>
                                                <div><span class="a-color-secondary">Signup and login form with proper validation in codeigniter. And maintain
                                                   session also with logout feature.</span><span class="a-color-secondary">
                                 <a >You just logged in</a></span></div>
                                 </div>
                                 <div class="clearfix"></div>
                                 </div>
                                 <div class="clearfix"></div>
                                 </div>
                                 </div>
                                 
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="ya-card-cell2 card_height">
                                 <a href="<?php echo base_url('cdashboard/task2'); ?>" class="ya-card__whole-card-link">
                                    <div data-card-identifier="YourOrders" class="a-box ya-card--rich">
                                       <div class="a-box-inner">
                                          <div class="col-md-12">
                                             <p class="icon_p">
                                                <i class="dashicon" ><b>2</b></i>
                                             </p>
                                             <div class="col-md-12 col-sm-12 col-xs-12 dash_content">
                                                <h2 class="a-spacing-none ya-card__heading--rich a-text-normal">
                                                   Task 2
                                                </h2>
                                                <div><span class="a-color-secondary">Find the missing number from the series // 2,3,4,5,6,7,9</span><span class="a-color-secondary">
                                 <a href="<?php echo base_url(''); ?>">Click to View task</a></span></div>
                                 </div>
                                 <div class="clearfix"></div>
                                 </div>
                                 <div class="clearfix"></div>
                                 </div>
                                 </div>
                                 </a>
                              </div>
                           </div>
                           <div class="clearfix"></div>
                        </div>
                        <div class="col-md-12 customer_dash">
                           <div class="col-md-6">
                              <div class="ya-card-cell3 card_height" onclick="window.location='<?php echo base_url('cdashboard/task3'); ?>'">
                                 
                                    <div data-card-identifier="YourOrders" class="a-box ya-card--rich">
                                       <div class="a-box-inner">
                                          <div class="col-md-12">
                                             <p class="icon_p">
                                                <i class="dashicon" ><b>3</b></i>
                                             </p>
                                             <div class="col-md-12 col-sm-12 col-xs-12 dash_content">
                                                <h2 class="a-spacing-none ya-card__heading--rich a-text-normal">
                                                   Task 3
                                                </h2>
                                                <div><span class="a-color-secondary">Write a program to create a form of creating dynamic nested menus? Also
                                                   show the list of menus.</span><span class="a-color-secondary">
                                 <a href="<?php echo base_url(''); ?>">Click to View task</a></span></div>
                                 </div>
                                 <div class="clearfix"></div>
                                 </div>
                                 <div class="clearfix"></div>
                                 </div>
                                 </div>
                                 
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="ya-card-cell1 card_height " onclick="window.location='<?php echo base_url('corder'); ?>'" >
                                
                                    <div data-card-identifier="YourOrders" class="a-box ya-card--rich">
                                       <div class="a-box-inner">
                                          <div class="col-md-12">
                                             <p class="icon_p ">
                                                <i class="dashicon" ><b>4</b></i>
                                             </p>
                                             <div class="col-md-12 col-sm-12 col-xs-12 dash_content">
                                                <h2 class="a-spacing-none ya-card__heading--rich a-text-normal">
                                                   Task 4
                                                </h2>
                                                <div><span class="a-color-secondary">Create an invoice form with dynamic product fields and process the
                                                   payment of the grand total amount of all products added in that form using
                                                   razorpay payment gateway in a checkout page.task</span>
                                                   <span class="a-color-secondary">
                                 <a href="<?php echo base_url(''); ?>">Click to View task</a></span>
                                 </div>
                                 </div>
                                 <div class="clearfix"></div>
                                 </div>
                                 <div class="clearfix"></div>
                                 </div>
                                 </div>
                                
                              </div>
                           </div>
                           <div class="clearfix"></div>
                        </div>
                     </div>
                  </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="clearfix"></div>
</div>