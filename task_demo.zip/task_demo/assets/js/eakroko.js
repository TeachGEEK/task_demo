function clearAll() {
    $("input[type=email],input[type=file],input[type=hidden],input[type=text],input[type=number],textarea").val('');
    $('input:checkbox').removeAttr('checked');
}