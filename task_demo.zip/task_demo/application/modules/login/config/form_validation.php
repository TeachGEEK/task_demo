<?php

$config = array(
                'user_valid_login' => array(array(
                                        'field'   => 'email', 
                                        'label'   => 'Username', 
                                        'rules'   => 'trim|required|xss_clean'
                                    ),
                                    array(
                                        'field'   => 'password', 
                                        'label'   => 'Password', 
                                        'rules'   => 'trim|required|xss_clean'
                                    ))
               );
               
?>