 <section>
   <div class="img-container porter_partner_home_img signup_content_head">
     <div class="col-md-12">
      <div class="box box-color box-bordered signup_content">
          <div class="col-md-10">
        <h2 class="heading_kyc">
            <strong class="heading_log"><i class="fa fa-user-circle-o" aria-hidden="true"></i> Profile</strong>
        </h2>
          <h3 class="sub_head_signup">Customer Name</h3>
       
        </div>
        <div class="col-md-2">
            <p data-toggle="modal" data-target="#myModal">
           <i class="fa fa-lock" aria-hidden="true"></i> Change Password</p>
            <!--<p <?php echo base_url('clogin/clogoutAction');?>> <i class="fa fa-edit" aria-hidden="true"></i>Logout</p>-->
        </div>
        <div class="clearfix"></div>
            <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Change Password</h4>
        </div>
        <div class="modal-body">
          <form>
               <div class="div_block">
                <label for="cust_email"><b>Old Password</b></label>
                <input type="text" placeholder="Enter Old Password" class="form-control" name="cust_email" required>
                </div>
                 <div class="div_block">
                <label for="cust_email"><b>New Password</b></label>
                <input type="text" placeholder="Enter New Password" class="form-control" name="cust_email" required>
                </div>
                 <div class="div_block">
                <label for="cust_email"><b>Confirm New Password</b></label>
                <input type="text" placeholder="Enter Confirm New Password" class="form-control" name="cust_email" required>
                </div>
                <input type="submit" class="form_sub" value="Submit" >
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
          <hr>
       <p class="kyc_para"><?php if($this->session->flashdata('item')) { ?>
			<div class="alert alert-success">
			<?php echo $this->session->flashdata('item'); ?>
			</div>
			<?php } ?></p>
       <div class="box-content nopadding">
       
        <div class="tab-content padding tab-content-inline tab-content-bottom">
          <div class="tab-pane active" id="profile">
           <div class="login-body my_login_body">
             <form action="<?php echo base_url('clogin/csignupAction') ?>" method="POST" id="customer-signup-form" class="form-horizontal">
              <div class="myform_cont">
                  <h3><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Basic Information</h3>
                  <hr>
                <div class="div_block col-md-12">
                 <label for="cust_name"><b>Full Name</b></label>
                 <input type="text" placeholder="Enter Full Name" class="form-control" name="cust_name" required>
                </div>
               
				<div class="div_block col-md-6">
                 <label for="cust_company_name"><b>Customer Company Name</b></label>
                 <input type="text" placeholder="Customer Company Name" class="form-control" name="cust_company_name" required> 
                </div>
                <div class="div_block col-md-6">
                 <label for="cust_gst_number"><b>Customer GST Number</b></label>
                 <input type="text" placeholder="Customer GST Number" class="form-control cust_gst_number"  name="cust_gst_number" required> 
                </div>
				  
                 <div class="div_block col-md-6">
                 <label for="cust_mobile_no"><b>Mobile Number</b></label>
                 <input type="number" placeholder="Enter Contact" class="form-control cust_mobile_no" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="10" name="cust_mobile_no" required> 
                </div>
				
                <div class="div_block col-md-6">  
                 <label for="cust_email"><b>Email</b></label>  
                 <input type="email" placeholder="Enter Eamil" class="form-control" name="cust_email" required>
                </div>
                <div class="div_block col-md-6">
                 <label for="cust_password"><b>Password(6 Characters Minimum)</b></label>
                 <input type="password" placeholder="Enter Password" class="form-control password" minlength="6" maxlength="10" name="cust_password" required>
                </div>
                <div class="div_block col-md-6">
                 <label for="cnf_password"><b>Confirm Password</b></label>
                 <input type="password" placeholder="Enter Confirm Password" class="form-control cnf_password" minlength="6" maxlength="10" name="cnf_password" required>
                </div>
                <div class="clearfix"></div>
                <input  type="submit" value="Submit" class="form_sub" id="btn-submitt">
              </div>
           </form>
         </div>
       </div>
    </div>
    </div>
    <div class="box-content nopadding">
     
        <div class="tab-content padding tab-content-inline tab-content-bottom">
          <div class="tab-pane active" id="profile">
           <div class="login-body my_login_body">
             <form action="<?php echo base_url('clogin/csignupAction') ?>" method="POST" id="customer-signup-form" class="form-horizontal">
              <div class="myform_cont">
                  <h3><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Company Information</h3>
                  <hr>
                <div class="div_block col-md-6">
                 <label for="cust_name"><b>Name</b></label>
                 <input type="text" placeholder="Enter Full Name" class="form-control" name="cust_name" required>
                </div>
                <div class="div_block col-md-6">
                 <label for="cust_name"><b>GSTN Number</b></label>
                 <input type="text" placeholder="Enter Full Name" class="form-control" name="cust_name" required>
                </div>
               
				<div class="div_block col-md-6">
                 <label for="cust_company_name"><b>Number Of Machine</b></label>
                 <input type="text" placeholder="Customer Company Name" class="form-control" name="cust_company_name" required> 
                </div>
                <div class="div_block col-md-6">
                 <label for="cust_gst_number"><b>Number Of Genrator</b></label>
                 <input type="text" placeholder="Customer GST Number" class="form-control cust_gst_number"  name="cust_gst_number" required> 
                </div>
				  
                 <div class="div_block col-md-6">
                 <label for="cust_mobile_no"><b>Approximate Fuel Consumption</b></label>
                 <input type="number" placeholder="Enter Contact" class="form-control cust_mobile_no" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="10" name="cust_mobile_no" required> 
                </div>
				
               
							<div class="col-md-6">
								<label>Enter Address Line 1</label>
								<textarea name="caddress" class="form-control" placeholder="Company Address Line" required=""></textarea>
							</div>
							<div class="col-md-6">
								<label>Company Area</label>
								<textarea name="carea" class="form-control" placeholder="Company Area" required=""></textarea>
							</div>
							
					
            
                <div class="col-md-6">
								<label>Land Mark</label>
								<input type="text" name="clandmark" class="form-control" placeholder="Land Mark" required="">
							</div>
							<div class="clearfix"></div>
							<div class="col-md-6">
								<label>City</label>
								<select class="form-control" name="dcity" >
								  <?php foreach ($city as $key => $val) { ?>
									<option value="<?php echo $val['city_id']; ?>"><?php echo ucfirst($val['city_name']); ?></option>
								  <?php } ?>
								</select>				
								</div>
								<div class="col-md-6">
								<label>Pin Code</label>
								<input class="form-control" type="text" name="cpin" maxlength="6" placeholder="Pin Code" required="">
							</div>
                <input  type="submit" value="Submit" class="form_sub" id="btn-submitt">
              </div>
           </form>
         </div>
       </div>
    </div>
    </div>
    </div>
    </div>
   
    <div class="clearfix"></div>
    </div>
</section>
<script type="text/javascript"> 
   $(document).ready(function() {
    /* $(".cust_gst_number").change(function () {    
		var inputvalues = $(this).val();    
		var gstinformat = new RegExp('^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$');    
		if (gstinformat.test(inputvalues)) {    
			return true;    
		} else {    
			alert('Please Enter Valid GSTIN Number');    
			$(".cust_gst_number").val('');    
			$(".cust_gst_number").focus();      
		}      
	});  */
    $('.cust_gst_number').on('change', function () { 
            var statecode = $(this).val().substring(0, 2);
            var pancarno = $(this).val().substring(2, 12);
            var entityNumber = $(this).val().substring(12, 13);
            var defaultZvalue = $(this).val().substring(13, 14);
            var checksumdigit = $(this).val().substring(14, 15);
            if ($(this).val().length != 15) {
                alert('GST Number is invalid');
                $(this).focus();
                return false;
            }
            if (pancarno.length != 10) {
                alert('GST number is invalid ');
                $(this).focus();
                return false;
            }
            if (defaultZvalue !== 'Z') {
                alert('GST Number is invalid Z not in Entered Gst Number');
                $(this).focus();
            }

            if ($.isNumeric(statecode)) {
                $('#gst_state_code').val(statecode).trigger('change');
            } else {
                alert('Please Enter Valid State Code');
                $(this).focus();
            }

            if ($.isNumeric(checksumdigit)) {
                return true;
            } else {
                alert('GST number is invalid last character must be digit');
                $(this).focus();

            }

        });	
			$(".cnf_password").change(function () {    
                var password = $(".password").val();    
				var cnf_password = $(".cnf_password").val();
                if (password == cnf_password) {    
                    return true;    
                } else {    
                    alert('Confirmed Password Does Not Matches To The Entered Password');    
                    $(".cnf_password").val('');    
                    $(".cnf_password").focus();     
                }       
            }); 
			$(".cust_mobile_no").change(function () {    
                    var cust_mobile_no = $(".cust_mobile_no").val(); 
				if (cust_mobile_no.length ==  10) {    
                    return true;    
                } else {    
                    alert('Enter Valid Mobile Number');    
                    $(".cust_mobile_no").val('');    
                    $(".cust_mobile_no").focus();           
                }       
            }); 
 
	$('#customer-signup-form').submit(function(event) {
    event.preventDefault(); 
    var formData = new FormData(this);
	$.ajax({
      type:'POST',
      url:$(this).attr('action'),
      data:formData,
      cache:false,
      contentType: false, 
      processData: false,
      beforeSend: function(){
        $('#btn-submitt').html('&ensp;Loading&ensp;<img src="<?php echo base_url('assets/img/loader.gif')?>">');
        $('#btn-submitt').attr('disabled','disabled');
      },
      success:function(res){
        
        if(res.trim() == 'true'){
        
          setTimeout(function() {
            
            $('#btn-submitt').removeAttr('disabled');
            $('#btn-submitt').html('Save change'); 
          },500)
		  
		 window.location.href = "<?php echo base_url('kyc');?>";
  
          toastr.success('Logged In Successfully..',{timeOut: 3000}); 
 
        } else {

          setTimeout(function() {
            toastr.error('Server error try agains..',{timeOut: 2000});
          },500);
        
        }

      }
    });
});
	
   
   });
   
   
   
</script>