
  <div class="desktop_footer_wrapper">
    <div class="footer_content_wrapper">
      <div class="footer">
        <div class="footer_upper">
          <div class="column1 column">
            <div class="footer_head">
              <a href="index.php" class="home_page_link">Babla Brothers</a>
            </div>

            <div class="social_media">
              <div class="text">
                <h3 class="simple_lines">  GET SOCIAL</h3>
              </div>
              <div class="icon_container">
                <div class="social_media_icon facebook">
                  <a href="https://www.facebook.com/BablaBrothers/" target="blank" class="social_media_link"></a>
                </div>

            

           
                <div class="social_media_icon youtube">
                  <a href="#" target="blank" class="social_media_link"></a>
                </div>


              </div>
            </div>

          </div>
          <div class="column2 column track_section">
            <div class="column_header">COMPANY</div>
            <div class="column_content">
              <span>
                  <h3 class="simple_lines">
                <a href="about_us" target="blank" class="track_link">About Us</a>
                </h3>
              </span>
            </div>
            <div class="column_content">
              <span>
                   <h3 class="simple_lines">
                <a href="delivery_information.php" target="blank" class="track_link">24x7 Delivery</a>
                  </h3>
              </span>
            </div>
            <div class="column_content">
              <span>
                     <h3 class="simple_lines">
                <a href="how_it_work.php" target="blank" class="track_link">How it Works</a>
                </h3>
              </span>
            </div>
         </div>
          <div class="column3 column track_section">
            <div class="column_header">SUPPORT</div>

            <div class="column_content">
              <span>
                      <h3 class="simple_lines">
                <a href="privacy_policy.php" target="blank" class="track_link">Privacy Policy</a>
                </h3>
              </span>
            </div>
            <div class="column_content">
              <span>
                     <h3 class="simple_lines">
                <a href="terms_condition.php" target="blank" class="track_link">Terms of service</a>
                </h3>
              </span>
            </div>
            <div class="column_content">
                   <h3 class="simple_lines">
              <span>
                <a href="faq.php" target="blank" class="track_link">FAQs</a>
              </span>
              </h3>
            </div>
          </div>

          <div class="column4 column porter_cities">
            <div class="column_header">
              CONTACT US
            </div>
            <div class="column_content">
              <span>
                <a href="#">
                  <h2>
                    9425204660
                  </h2>
                </a>
              </span>
            </div>
            <div class="column_content">
              <span>
                <a href="#">
                  <h2>9827152046</h2>
                </a>
              </span>
            </div>
          </div>

          <div class="column5 column porter_verticals">
            <div class="column_header">
              ADDRESS
            </div>
            <div class="column_content">
              <span>
                <a href="index.php" target="_blank">
                  <h2> Babla Brothers, Rawabhata, Bilaspur Road, Raipur</h2>
                </a>
              </span>
            </div>
            <div class="column_content">
              <span>
                <a href="#" target="_blank">
                  <h2>Email : Bablabrothersraipur@gmail.com</h2>
                </a>
              </span>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>




  </div>
</body>

<script src="d3o1t8vp7n8wsg.cloudfront.net/assets/website_revamp/home/desktop_home-da24de6a928f2198a6c66723aaedafc319570e1d93d952875a4144dbb98dd150.js"></script>

<script>
  let modalId = $('#image-gallery');

$(document)
  .ready(function () {

    loadGallery(true, 'a.thumbnail');

    //This function disables buttons when needed
    function disableButtons(counter_max, counter_current) {
      $('#show-previous-image, #show-next-image')
        .show();
      if (counter_max === counter_current) {
        $('#show-next-image')
          .hide();
      } else if (counter_current === 1) {
        $('#show-previous-image')
          .hide();
      }
    }

    /**
     *
     * @param setIDs        Sets IDs when DOM is loaded. If using a PHP counter, set to false.
     * @param setClickAttr  Sets the attribute for the click handler.
     */

    function loadGallery(setIDs, setClickAttr) {
      let current_image,
        selector,
        counter = 0;

      $('#show-next-image, #show-previous-image')
        .click(function () {
          if ($(this)
            .attr('id') === 'show-previous-image') {
            current_image--;
          } else {
            current_image++;
          }

          selector = $('[data-image-id="' + current_image + '"]');
          updateGallery(selector);
        });

      function updateGallery(selector) {
        let $sel = selector;
        current_image = $sel.data('image-id');
        $('#image-gallery-title')
          .text($sel.data('title'));
        $('#image-gallery-image')
          .attr('src', $sel.data('image'));
        disableButtons(counter, $sel.data('image-id'));
      }

      if (setIDs == true) {
        $('[data-image-id]')
          .each(function () {
            counter++;
            $(this)
              .attr('data-image-id', counter);
          });
      }
      $(setClickAttr)
        .on('click', function () {
          updateGallery($(this));
        });
    }
  });

// build key actions
$(document)
  .keydown(function (e) {
    switch (e.which) {
      case 37: // left
        if ((modalId.data('bs.modal') || {})._isShown && $('#show-previous-image').is(":visible")) {
          $('#show-previous-image')
            .click();
        }
        break;

      case 39: // right
        if ((modalId.data('bs.modal') || {})._isShown && $('#show-next-image').is(":visible")) {
          $('#show-next-image')
            .click();
        }
        break;

      default:
        return; // exit this handler for other keys
    }
    e.preventDefault(); // prevent the default action (scroll / move caret)
  });

  function my_img1() {
    
      if(document.getElementById('my_img_detail1').style.display == 'block'){
        
            document.getElementById('my_img_detail2').style.display = 'none';
    document.getElementById('my_img_detail3').style.display = 'none';
    document.getElementById('my_img_detail4').style.display = 'none';
      }
      else if(document.getElementById('my_img_detail1').style.display == 'none'){
    document.getElementById('my_img_detail1').style.display = 'block';
       document.getElementById('my_img_detail2').style.display = 'none';
    document.getElementById('my_img_detail3').style.display = 'none';
    document.getElementById('my_img_detail4').style.display = 'none';
      }
  }
  function my_img2() {
    document.getElementById('my_img_detail1').style.display = 'none';
    document.getElementById('my_img_detail2').style.display = 'block';
    document.getElementById('my_img_detail3').style.display = 'none';
    document.getElementById('my_img_detail4').style.display = 'none';
  }

  function my_img3() {
    document.getElementById('my_img_detail1').style.display = 'none';
    document.getElementById('my_img_detail2').style.display = 'none';
    document.getElementById('my_img_detail3').style.display = 'block';
    document.getElementById('my_img_detail4').style.display = 'none';
  }
  function my_img4() {
    document.getElementById('my_img_detail1').style.display = 'none';
    document.getElementById('my_img_detail2').style.display = 'none';
    document.getElementById('my_img_detail3').style.display = 'none';
    document.getElementById('my_img_detail4').style.display = 'block';
  }
</script>

<script>

  function my_img11() {
    
      if(document.getElementById('my_img_detail11').style.display == 'block'){
        
            document.getElementById('my_img_detail12').style.display = 'none';
    document.getElementById('my_img_detail13').style.display = 'none';
   
      }
      else if(document.getElementById('my_img_detail11').style.display == 'none'){
    document.getElementById('my_img_detail11').style.display = 'block';
       document.getElementById('my_img_detail12').style.display = 'none';
    document.getElementById('my_img_detail13').style.display = 'none';
  
      }
  }
  function my_img12() {
    document.getElementById('my_img_detail11').style.display = 'none';
    document.getElementById('my_img_detail12').style.display = 'block';
    document.getElementById('my_img_detail13').style.display = 'none';
   
  }

  function my_img13() {
    document.getElementById('my_img_detail11').style.display = 'none';
    document.getElementById('my_img_detail12').style.display = 'none';
    document.getElementById('my_img_detail13').style.display = 'block';
  
  }

</script>


<!-- Mirrored from porter.in/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 15 Feb 2021 05:04:41 GMT -->
