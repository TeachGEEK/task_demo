<div class="img-container porter_partner_home_img cpayment_address_head">
   <div class="">
      <div class="box box-color box-bordered order_history_head">
         <h2 class="heading_kyc"><strong class="heading_log"><i class="fa fa-arrow-right" aria-hidden="true"></i>Task - 2</strong></h2>
         <hr class="hr_line">
         <div class="box-content nopadding top_box">
            </ul>
            <div class="tab-content padding tab-content-inline tab-content-bottom">
               <div class="tab-pane active" id="profile">
                  <div class="login-body my_login_body">
                     <div class="myform_cont container" style="padding-bottom:100px;">
                        <form action="<?php echo base_url('cdashboard/missing_number') ?>" method="POST" id="task2_form" autocomplete="anyrandomstring" class="form-horizontal">
                           <div class="div_block col-md-12">
                              <label for="numbers"><b>Enter Number between 1 - 9 (in comma seperated form)</b></label><span id="numbers-error" class="signup_error"></span>
                              <input type="text" placeholder="Ex : (2,3,4,5,6,7,9)" class="form-control numbers" name="numbers" required>
                           </div>
                           <input  type="submit" value="Find Missing Number" class="form_sub" id="btn-submitt">
                        </form>
                     </div>
                  </div>
                  <div class="col-md-12">
                     <div class="container" >
                        <label for="numbers" style="display: flex;">
                        <b>
                           <h3>Result : </h3>
                        </b>
                        <h3 class="text-primary"id="result"></h3>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="clearfix"></div>
</div>
<script type="text/javascript">
   $(".numbers").change(function() {
     if ( $(this).val().match('^[1-9](,[1-9])+$') ) {
         return true;    
     } else {
         $('#numbers-error').html("Enter Numbers in valid formate!"); 
             setTimeout(function(){
                 $(".signup_error").html('');
             }, 2000);
                        
                     $(".numbers").val('');    
                     $(".numbers").focus();     
     }
    });
    
   
   
   
   
   $('#task2_form').submit(function(event) {
     event.preventDefault(); 
     var formData = new FormData(this);
    $.ajax({
       type:'POST',
       url:$(this).attr('action'),
       data:formData,
       cache:false,
       contentType: false, 
       processData: false,
     
       success:function(res){
         
         if(res){
         $('#result').html(res);
    
         } else {
    		$('#signup-error').html(res);
         setTimeout(function(){
                 $(".signup_error").html('');
             }, 2000);   
         
         }
    
       } 
    
     });
    });
    
   
</script>