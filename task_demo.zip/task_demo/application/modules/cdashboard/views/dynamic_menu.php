
<div class="img-container porter_partner_home_img cpayment_address_head">
   <div class="">
      <div class="box box-color box-bordered order_history_head">
         <h2 class="heading_kyc"><strong class="heading_log"><i class="fa fa-arrow-right" aria-hidden="true"></i>Task - 3</strong></h2>
         <hr class="hr_line">
         <div class="box-content nopadding top_box">
            </ul>
            <div class="tab-content padding tab-content-inline tab-content-bottom">
               <div class="tab-pane active" id="profile">
                  <div class="login-body my_login_body">
                     <div class="myform_cont container" style="padding-bottom:100px;">
                       <nav id="topBar" class="mt-3">

                           <ul>
                           	 <?php foreach ($menu as $key => $menulist){  ?>
                              <li>
                                 <a href="#"><?php echo $menulist['menuname']; ?><i class="fa fa-angle-down"></i></a>
                                 <ul class="subMenu">
                                 	<?php foreach ($submenu as $key => $submenulist){  

                                 		if($submenulist['submenu_id']==$menulist['menuid']){?>
									<li>
                                       <a href="#"><?php echo $submenulist['menuname']; ?> &nbsp;<i class="fa fa-angle-right"></i></a>
                                       <ul class="subMenu">
                                       		<?php foreach ($subsubmenu as $key => $subsubmenulist){  

                                 		if($subsubmenulist['sub_submenu_id']==$submenulist['menuid']){?>
                                          
                                          <li>
                                             <a href="#"><?php echo $subsubmenulist['menuname']; ?> &nbsp;<i class="fa fa-angle-right"></i></a>
                                             
                                          </li>
                                           <?php } }?>
                                       </ul>
                                    </li>
                                    <?php } }?>
                                    
                                 </ul>
                              </li>
                          	<?php } ?>
                             
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="clearfix"></div>
</div>
<script type="text/javascript">
   $(".numbers").change(function() {
     if ( $(this).val().match('^[1-9](,[1-9])+$') ) {
         return true;    
     } else {
         $('#numbers-error').html("Enter Numbers in valid formate!"); 
             setTimeout(function(){
                 $(".signup_error").html('');
             }, 2000);
                        
                     $(".numbers").val('');    
                     $(".numbers").focus();     
     }
    });
    
   
   
   
   
   $('#task2_form').submit(function(event) {
     event.preventDefault(); 
     var formData = new FormData(this);
    $.ajax({
       type:'POST',
       url:$(this).attr('action'),
       data:formData,
       cache:false,
       contentType: false, 
       processData: false,
     
       success:function(res){
         
         if(res){
         $('#result').html(res);
    
         } else {
    		$('#signup-error').html(res);
         setTimeout(function(){
                 $(".signup_error").html('');
             }, 2000);   
         
         }
    
       } 
    
     });
    });
    // Hide SubMenus.
   $(".subMenu").hide();
   
   // Shows SubMenu when it's parent is hovered.
   $(".subMenu").parent("li").hover(function () {
   $(this).find(">.subMenu").not(':animated').slideDown(300);
   $(this).toggleClass("active ");
   });
   
   // Hides SubMenu when mouse leaves the zone.
   $(".subMenu").parent("li").mouseleave(function () {
   $(this).find(">.subMenu").slideUp(150);
   });
   
   // Prevents scroll to top when clicking on <a href="#"> 
   $("a[href=\"#\"]").click(function () {
   return false;
   });
   
</script>