 <style>
.signup_errorr
{
	color:#FF0000; 
	padding-left:15px;
	width:600px;
}
</style>
 <div class="img-container porter_partner_home_img">
    <div class="col-md-12 box_side">
        <div class="box box-color box-bordered signin_content">
           <h2 class="heading_kyc">
               <strong class="heading_log">Password Reseat</strong> 
			   
           </h2>
		   <br>
		   <br>
		      <h5 class="signup_errorr">This link has been expired .<a href="<?php echo base_url('clogin'); ?>">Click Here to go back to  login </a></h5>
            <hr>
           </ul>
		</div>
	</div>
</div>