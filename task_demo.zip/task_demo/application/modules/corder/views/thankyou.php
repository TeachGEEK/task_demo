<div class="img-container porter_partner_home_img cpayment_address_head">
   <div class="">
      <div class="box box-color box-bordered order_history_head">
         <h2 class="heading_kyc"><strong class="heading_log"><i class="fa fa-arrow-right" aria-hidden="true"></i>Thanks Giving</strong></h2>
         <hr class="hr_line">
         <div class="box-content nopadding top_box">
            </ul>
            <div class="tab-content padding tab-content-inline tab-content-bottom">
               <div class="tab-pane active" id="profile">
                  <div class="login-body my_login_body">
                     <div class="myform_cont container" style="padding-bottom:100px;">
                        <p class="large_font">
                        	Thanks for giving your time . I hope you Like my work .I have Modular Extensions - HMVC . I Have worked On Regular Codigniter too . But I personally like Modular Extention - HMVC because Modular Extensions makes the CodeIgniter PHP framework modular. Modules are groups of independent components, typically model, controller and view, arranged in an application modules sub-directory that can be dropped into other CodeIgniter applications.

                            <br>
                        	I tried to complete the task in very short span according to my understanding .Please Ignore design Errors and responsiveness errors(if any) , I have only focused on development part . If I have missed something , my apologies in advance .
                        	Feel free to ping me for any kind of doubt or explanation in my code. 

                        </p>

                     </div>
                  </div>
                  <div class="col-md-12">
                     <div class="container" >
                        <label for="numbers" >
                        <b>
                           <h3>Why You Should Hire Me : </h3>
                        </b><br>
                        <ul class="large_font">
                        	<li>I am a very Quick self learner , as a result I have also tried to make some working demo in react-native, fluter , reactjs </li>
                        	<li>I am good at designing , developing and database management. Therefore I can handle a small project all by myself</li>
                        	<li>Understanding the requirement and making logics according to the requirement is one of my strongest point</li>
                        	<li>I am a very creative and out of the box person ,I try to be as creative as I can , keeping timelimit in my mind . As a developer being creative on a frontend repreasantaion part is hard, but I always enjoy doing that without leaving my focus on development part . I have tried to show my creativity in this project too . I hope you would notice that .</li>

                        	<li>I am funny , sarcastic and full of positive vibes . This would help to keep office environment more healthy</li>
                        	<li>I write blogs also , I am good at content creating part too </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="clearfix"></div>
</div>
