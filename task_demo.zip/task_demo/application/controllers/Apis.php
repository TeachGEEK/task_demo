<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow- Methods: POST, GET, PUT, DELETE, OPTIONS'); 
header('Access-Control-Allow-Headers: X-Requested-With, content-type, X-Token, x-token');

class Api extends Controller 
{
	public function __Construct()
   	{
        parent::__Construct();
		$this->load->model("Api_model"); 
    }
	
	public function apiDoc()
	{
		$this->load->template('api_doc','',true);
	}

	public function userLogin()
	{
		$email = trim($this->input->post('email'));
		$pass  = trim($this->input->post('pass'));

		$query = $this->Api_model->appAuth($email,$pass); 

		if($query->num_rows() == 0)
		{
			$data = array('status'=>'false','error' => "Invalid Username And Password..");

		    echo json_encode($data,JSON_PRETTY_PRINT);
		}
		else
		{
			$userSesData = $this->getSession($email);

		    echo json_encode($userSesData,JSON_PRETTY_PRINT);
		}
	}

	public function userAuthRegister()
	{
		$fname         = trim($this->input->post('fname'));
		$lname         = trim($this->input->post('lname'));
		$email         = trim($this->input->post('email'));
		$pass          = trim($this->input->post('pass'));
		$mobile_no     = trim($this->input->post('mobile_no'));
		$profile_image = trim($this->input->post('profile_image'));
		$login_id      = trim($this->input->post('login_id'));
		$login_type    = trim($this->input->post('login_type'));

		$userData = array(
					  'user_first_name'	   => $fname, 
					  'user_last_name'     => $lname,            
	                  'user_email' 		   => $email,
	                  'user_mobile_no' 	   => $mobile_no,
	                  'user_profile_image' => $profile_image,
	                  'user_login_id' 	   => $login_id,
	                  'user_type' 	       => 'users',
	                  'user_status' 	   => 'active',
	                  'user_created' 	   => date('Y-m-d H:i:s'),
	               );
	
		if(!empty($email)){

			$checkUser = $this->Api_model->socialAuth($email);

			if(empty($checkUser)){
				// Insert Data In Users Table
				if($login_type == 'app'){
					$userData['user_password']   = md5($pass);
					$userData['user_login_type'] = 'app';
				} 
				elseif($login_type == 'google') 
				{
					$userData['user_login_type'] = 'google';
				} 
				else 
				{
					$userData['user_login_type'] = 'facebook';
				}

				$user_id = $this->common->insert('users',$userData);

				// Create One in Address Table
				$this->common->insert('users_address',array('user_id'=>$user_id));
				
				// Create Wallet In Wallet Table
				$this->common->insert('wallet',array('user_id'=>$user_id));

			} else {
				if(empty($checkUser->user_profile_image)){
					$this->common->update('users',array('user_profile_image'=>$profile_image),array('user_email'=>$email));
				}
			}	

			$userSesData = $this->getSession($email);

			echo json_encode($userSesData,JSON_PRETTY_PRINT);
			
		} else {
			echo json_encode('Field is Required...');
		}
	}

	public function getSession($email)
	{
		$user = $this->Api_model->socialAuth($email);

		return array('status'          => 'true',
					 'user_id'         => $user->user_id,		               
					 'fname'	       => $user->user_first_name,		               
					 'lname'           => $user->user_last_name,            
					 'email' 	       => $user->user_email,
					 'mobile_no'       => $user->user_mobile_no,
					 'profile_image'   => $user->user_profile_image,
					 'login_type'      => $user->user_login_type,
	               );
	}

	public function getUserAddr()
	{
		$user_id = trim($this->input->post('user_id'));
		
		$userAddrData = $this->common->getDescData('*','users_address',array('user_id'=>$user_id),'addr_id');

		echo json_encode($userAddrData,JSON_PRETTY_PRINT);
	}

	public function addUserAddr()
	{
		$addr_id     = trim($this->input->post('addr_id'));
		$user_id     = trim($this->input->post('user_id'));
		$user_addr   = trim($this->input->post('user_addr'));
		$user_loc    = trim($this->input->post('user_loc'));
		$user_state  = trim($this->input->post('user_state'));
		$user_city   = trim($this->input->post('user_city'));
		$user_pin    = trim($this->input->post('user_pin'));
		$user_lat    = trim($this->input->post('user_lat'));
		$user_lng    = trim($this->input->post('user_lng'));

		$userAddrData = array(
						  'user_id'	   			=> $user_id, 
						  'user_addr_address'   => $user_addr,            
		                  'user_addr_location'  => $user_loc,
		                  'user_addr_state' 	=> $user_state,
		                  'user_addr_city'      => $user_city,
		                  'user_addr_pincode' 	=> $user_pin,
		                  'user_addr_lat' 	    => $user_lat,
		                  'user_addr_lng' 	    => $user_lng
		               );

		if(empty($addr_id)){
			$this->common->insert('users_address',$userAddrData);
		} else {
			$this->common->update('users_address',$userAddrData,array('addr_id'=>$addr_id));
		}

		echo json_encode('success');
	}

	public function getUserWallet()
	{
		$user_id = trim($this->input->post('user_id'));

		$userWalletData = $this->common->getJoin(
                                      'wl.wallet_id,wl.wallet_amt,wh.wallet_history_id,wh.wallet_history_descrp,wh.wallet_history_credit,wh.wallet_history_debit,wh.wallet_history_modified',
                                      'wallet as wl',
                                      array('wallet_history as wh'),
                                      array('wl.user_id = wh.user_id'),
                                      array('INNER'),
                                      array('wl.user_id' => $user_id),
                                      'wh.wallet_history_id'
                                   );

		echo json_encode($userWalletData,JSON_PRETTY_PRINT);
		
	}

	public function updateUserWallet()
	{
		$user_id       = trim($this->input->post('user_id'));
		$wallet_descrp = trim($this->input->post('wallet_descrp'));
		$wallet_credit = trim($this->input->post('wallet_credit'));
		$wallet_debit  = trim($this->input->post('wallet_debit'));

		// Get Prv Amount Form Data
		$amt = $this->common->getDescData('wallet_amt','wallet',array('user_id'=>$user_id),'wallet_id')->wallet_amt;

		// Debit Amount in Your Wallet
		if(!empty($wallet_credit)){
			$wallet = array('wallet_amt' => $amt - $wallet_credit);
		}

		// Credit Amount in Your Wallet
		if(!empty($wallet_debit)){
			$wallet = array('wallet_amt' => $amt - $wallet_debit);
		}

		$this->common->update('wallet',$wallet,array('user_id'=>$user_id));

		$walletHistory = array(
						  'user_id'	   		       => $user_id, 
						  'wallet_history_descrp'  => $wallet_descrp,            
		                  'wallet_history_credit'  => $wallet_credit,
		                  'wallet_history_debit'   => $wallet_debit
		               );
		
		$this->common->insert('wallet_history',$walletHistory);

		echo json_encode('success');

	}

	public function getAllCatg()
	{
		$catgData = $this->common->getData('*','category',array('catg_status'=>'active'));

		echo json_encode($catgData,JSON_PRETTY_PRINT);
	}

	public function getAllSubCatg()
	{
		$subCatgData = $this->common->getData('*','sub_category',array('sub_catg_status'=>'active'));

		echo json_encode($subCatgData,JSON_PRETTY_PRINT);
	}

	public function getSubByCatgId()
	{
		$catg_id = $this->input->post('catg_id');

		$subCatgData = $this->common->getData('*','sub_category',array('catg_id'=>$catg_id,'sub_catg_status'=>'active'));

		if(empty($subCatgData)){
			echo json_encode('No Result Found',JSON_PRETTY_PRINT);
		} else {
			echo json_encode($subCatgData,JSON_PRETTY_PRINT);
		}
	}

	public function getAllProduct()
	{
		$catg_id 	 = $this->input->post('catg_id');
		$sub_catg_id = $this->input->post('sub_catg_id');

		$prodData = $this->common->getJoin(
                                      'ct.catg_name,st.sub_catg_name,p.*',
                                      'products as p',
                                      array('category as ct','sub_category as st'),
                                      array('p.prod_catg_id = ct.catg_id','p.prod_sub_catg_id = st.sub_catg_id'),
                                      array('LEFT','LEFT'),
                                      array('p.prod_sub_catg_id' => $sub_catg_id),
                                      'p.prod_id'
                                   );

		echo json_encode($prodData,JSON_PRETTY_PRINT);
	}

	public function deviceRegister()
	{
		$dev_token   = $this->input->post('device_token');
		$dev_name    = trim($this->input->post('device_name'));
		$dev_user_id = trim($this->input->post('user_id'));

		$deviceData = array(
						  'device_token'   => $dev_token, 
						  'device_name'    => $dev_name,            
		                  'device_user_id' => $dev_user_id
		               );

		if(empty($dev_name)){
			$this->common->insert('device_register',$deviceData);
		} else {
			$this->common->update('device_register',$deviceData,array('device_name'=>$dev_name));
		}

		echo json_encode('Device Register SucessFully...');
	}
}
?>

