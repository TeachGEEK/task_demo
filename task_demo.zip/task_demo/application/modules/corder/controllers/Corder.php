<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Corder extends MX_Controller 
{
	public function __Construct()
   	{
       parent::__Construct();
	   if(empty(
	   $this->session->userdata('user_id'))){
	   redirect(base_url('clogin')); 
	  }	
	 
	  $this->load->model("Corder_model");
    }
	
	public function index()
	{
		$cust_id=$this->session->userdata('user_id');
		$data['pro_list'] = $this->common->getData('*','product','','prod_id');

		$this->load->homepage('corder',$data,TRUE);
	}
	public function priceDetails()
	{
       
       $prod_id = $this->input->post('prod_id'); 

       $data = $this->common->getData('*','product',array('prod_id' => $prod_id ),'prod_id');;
      
       if(!empty($data)){
		echo json_encode(array("status"=>true,"res"=>$data));
		}else{ echo json_encode(array("status"=>false,"res"=>'No details Available')); ;}
		

	}
	
	public function cpayment()
	{
		$order_id = $this->input->get('order_id');
		$data['payment_info'] = $this->common->getById('bb_order',array('order_id' => $order_id ));  
        
        
        $this->load->homepage('cpayment' , $data ,TRUE);
	}
	
   
	public function orderAction()  
	{   $cust_id=$this->session->userdata('user_id');
		$total_amount  = $this->input->post('grand_total');
		$prod_id  = $this->input->post('prod_id');
		$prod_id = implode(",",$prod_id);
		
	    $data = array(
	    	'cust_id'  	         => $cust_id,
	    	'total_amount'   => $total_amount,
	    	'prod_id'       =>  $prod_id,
	    	 'created'  		     => date('Y-m-d H:i:s')
	        ); 
		 $this->common->insert('bb_order',$data); 
		$insert_id = $this->db->insert_id();
			echo  $insert_id;  
	}
	
	public function razorPaySuccess()
    { 
		$order_id = $this->input->post('order_id');
		
		$data = [
				   'cust_id' => $this->session->userdata('user_id'),
				   'trans_id' => $this->input->post('razorpay_payment_id'),
				];
		
		$this->db->update('bb_order', $data,array('order_id' => $order_id));
		
		$arr = array('msg' => 'Payment successfully credited', 'status' => true);  
		
		echo json_encode($arr);
	}
	public function thankyou()
    { 

		$this->load->homepage('thankyou','',TRUE);

    }
	
	
    
}
?>
