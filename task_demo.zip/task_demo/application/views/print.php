<html>
<head>
	<title><?php echo date('d-M-Y',strtotime($dates)); ?></title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
	<center><?php echo date('d-M-Y',strtotime($dates)); ?></center>
	<div class="table-responsive">
		<table class="table" style="text-align:center;">
		  <tr>
		    <td>S.NO</td>
		    <td>PRODUCT_NAME</td>
		    <td>PRODUCT_TYPE</td>
		    <td>QUANTITY</td>
		    <td>REQUIRED QTY</td>
		  </tr>
		  <?php foreach ($qty as $key => $val) { 

		  	if($val['prod_pur_qty_type'] == 'Gram'){
                $qty = round((($val['prod_pur_qty'] * $val['cnt']) / 1000),2).' lt';
            } else if($val['prod_pur_qty_type'] == 'Dozen'){
                $qty = intval($val['prod_pur_qty'] * $val['cnt']).' Dozen';
            } else if($val['prod_pur_qty_type'] == 'Piece'){
                $qty = intval($val['prod_pur_qty'] * $val['cnt']).' Piece';
            } else if($val['prod_pur_qty_type'] == 'Liter'){
                $qty = intval($val['prod_pur_qty'] * $val['cnt']).' Liter';
            } else {
                $qty = intval($val['prod_pur_qty'] * $val['cnt']).' Kg';
            }

		  	?>
		  	<tr>
			    <td><?php echo intval($key+1); ?></td>
			    <td><?php echo $val['prod_pur_name']; ?></td>
			    <td><?php echo $val['prod_pur_qty'].' '.$val['prod_pur_qty_type']; ?></td>
			    <td><?php echo $val['cnt']; ?></td>
			    <td><?php echo $qty; ?></td>
			  </tr>
		  <?php } ?>		 
		</table>
	</div>
</div>
</body>
</html>