


<body>
   <div class="body_wrapper">
   <?php $page_name= $this->uri->segment(2);
        ?>
<!--Headers start-->
<div class="header_wrapper blue_gradient_bg" >
   <div class="row">
      <div class="col-md-4">
         
            <h1 class="logo_title">Annu Upadhyay</h1>
         
      </div>
      
      <div id="mySidenav" class="sidenav" style="height:100%">
         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
         <h3 class="simple_lines"> <a href="tps://techgeek-ce5d0.web.app/about">About Annu Upadhyay<a></h3>
         <h3 class="simple_lines"><a href="https://techgeek-ce5d0.web.app/project">Her Projects</a></h3>
         
         <h3 class="simple_lines"><a href="<?php echo base_url('uploads/Annu_Upadhyay.pdf'); ?>">Her Resume</a></h3>
         <h3 class="simple_lines"><a href="https://www.linkedin.com/in/annu-upadhyay-2bb16811b/">Her LinkedIn</a></h3>
         <h3 class="simple_lines"><a href="https://github.com/TeachGEEK/">Her Github</a></h3>
         <h3 class="simple_lines"><a href="https://teach-geek.blogspot.com/">Her Blogs</a></h3>
         
      </div>
      
      <span style="font-size:30px;cursor:pointer;position:absolute;color:#fff;float: right;
    margin-right: 29px;position: relative;" class="my_btn" onclick="openNav()">&#9776; </span>
      <script>
         function openNav() {
           document.getElementById("mySidenav").style.width = "250px";
           document.getElementById("mySidenav").style.hight = "100%";
         }
         
         function closeNav() {
           document.getElementById("mySidenav").style.width = "0";
         }
      </script>
     <div class="col-md-2"></div>
      <div class="header_hooks_section flex-align-center col-md-6">
        
         <div class="right_container flex-align-center">
            <?php if(empty($this->session->userdata('username'))){ $homelink='';?>
            <a href="<?php echo base_url(); ?>" class="btn_link driver_with_us_btn flex-align-center">
               <div class="text_content">
                  <p class="section_header bold_porter_purple">#Beliver</p>
                  <p class="content normal_porter_purple">Annu Upadhyay</p>
               </div>
               <div class="joins_us bold_yellow">Login</div>
            </a>
            <?php  } else { $homelink='cdashboard'; ?>
            <a href="#" class="btn_link driver_with_us_btn flex-align-center">
               <div class="joins_us bold_yellow" onclick="window.location='<?php echo base_url('login/clogoutAction');?>'">Log Out</div>
            </a>
            <?php  }  ?>
            <div class="customer_care flex-align-center">
               <div class="customer_care_icon"></div>
               <div class="customer_care_number">
                  <div class="support_number bold_lightest">
                     <a href="tel:9425204660" class="mobile_link">7999960158 </a>|<a href="tel:9827152046" class="mobile_link"> upadhyayannu60@gmail.com</a>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </div>
</div>
<div class="offers_header_wrapper" >
   <div class="desk_menu">
      <div class="offers_login_section" scroll_target_name="header_track_order_form">
         
         <div class="left_container">
            <div class="links_section flex-align-center">
               <a class="btn_link <?php if($page_name == ''){echo 'current_page';} ?>" href="<?php echo base_url().$homelink ?>" event_value="home">
                  <h2 class="porter_vertical_text semi_bold_darker">Home</h2>
               </a>
               <a class="semi_bold_darker btn_link " target="_blank" href="https://techgeek-ce5d0.web.app/about">
               About Annu Upadhyay
               </a>
                <a class="semi_bold_darker btn_link " target="_blank" href="https://techgeek-ce5d0.web.app/project">
               Her Projects
               </a>
                <a class="semi_bold_darker btn_link " target="_blank" href="<?php echo base_url('uploads/Annu_Upadhyay.pdf'); ?>">
               Her Resume
               </a>
               
            </div>
         </div>
         <div class="right_container flex-align-center">
            <div class="login_button section_btn">
              <a class="semi_bold_darker btn_link " target="_blank" href="https://www.linkedin.com/in/annu-upadhyay-2bb16811b/">
               Her LinkedIn
               </a>
            </div>
            <div class="support_section section_btn ">
               <a class="semi_bold_darker btn_link " target="_blank" href="https://github.com/TeachGEEK/">
               Her Github
               </a>
              
            </div>
            <div class="support_section section_btn ">
                 <a class="semi_bold_darker btn_link " target="_blank" href="https://teach-geek.blogspot.com/">
               Her Blogs
               </a>
            </div>
         </div>
         
      </div>
   </div>
</div>
<!--Headers end-->
