-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2021 at 04:13 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `bb_order`
--

CREATE TABLE `bb_order` (
  `order_id` int(11) NOT NULL,
  `cust_id` int(11) DEFAULT NULL,
  `prod_id` varchar(50) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `trans_id` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bb_order`
--

INSERT INTO `bb_order` (`order_id`, `cust_id`, `prod_id`, `total_amount`, `trans_id`, `created`, `modified`) VALUES
(6, 4, '6,5', '46000.00', '', '2021-08-30 05:19:06', '2021-08-29 23:49:06'),
(7, 4, '5,6', '46000.00', 'pay_HrDc8XjFO98Gy1', '2021-08-30 05:23:16', '2021-08-30 00:54:10'),
(8, 7, '6,6', '44000.00', 'pay_HrEjHpA3JjWZgM', '2021-08-30 07:28:55', '2021-08-30 01:59:37');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` int(11) NOT NULL,
  `cust_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `cust_mobile_no` bigint(15) DEFAULT NULL,
  `cust_password` varchar(250) DEFAULT NULL,
  `cust_email` varchar(250) DEFAULT NULL,
  `kyc_status` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `cust_name`, `cust_mobile_no`, `cust_password`, `cust_email`, `kyc_status`, `created`, `modified`) VALUES
(4, 'Annu Upadhyay', 7999960158, 'e10adc3949ba59abbe56e057f20f883e', 'annu@gmail.com', NULL, '2021-08-29 17:35:15', '2021-08-29 12:05:15'),
(6, 'Annu', 7999999999, 'e10adc3949ba59abbe56e057f20f883e', 'adminn@gmail.com', NULL, '2021-08-30 07:25:25', '2021-08-30 01:55:25'),
(7, 'Annu', 7999960157, 'e10adc3949ba59abbe56e057f20f883e', 'adminnn@gmail.com', NULL, '2021-08-30 07:28:11', '2021-08-30 01:58:11');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `menuid` int(11) NOT NULL,
  `menuname` varchar(100) NOT NULL,
  `submenu_id` int(11) DEFAULT 0,
  `sub_submenu_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`menuid`, `menuname`, `submenu_id`, `sub_submenu_id`) VALUES
(1, 'Menu1', 0, 0),
(2, 'menu1Submenu1', 1, 0),
(3, 'Menu2', 0, 0),
(4, 'menu2Submenu1', 3, 0),
(5, 'Menu3', 0, 0),
(6, 'menu3 submenu1 subsubmenu1', 5, 7),
(7, 'Menu3submenu1', 5, 0),
(8, 'menu3 submenu2', 5, 0),
(9, 'menu3 submenu3', 5, 0),
(10, 'menu3 submenu4', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(250) CHARACTER SET utf8 NOT NULL,
  `selling_price` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prod_id`, `prod_name`, `selling_price`) VALUES
(1, 'Samsung Galaxy M31s (6GB RAM) ', 24000),
(2, 'OnePlus Nord', 22000),
(3, 'Nokia', 24000),
(4, 'Oppo', 22000),
(5, 'Micromax', 24000),
(6, 'Sony', 22000),
(7, 'Vivo', 24000),
(8, 'Boat', 22000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bb_order`
--
ALTER TABLE `bb_order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `cust_id` (`cust_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`menuid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bb_order`
--
ALTER TABLE `bb_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `menuid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
