<style type="text/css">
  table {
    border-collapse: separate;
    border-spacing: 31px 1em;
}
.form_sub{margin-top: 0px}
</style>
<div class="img-container porter_partner_home_img cpayment_address_head">
   <div class="">
      <div class="box box-color box-bordered order_history_head">
         <h2 class="heading_kyc"><strong class="heading_log"><i class="fa fa-arrow-right" aria-hidden="true"></i>Task - 4</strong></h2>
         <hr class="hr_line">
         <div class="box-content nopadding top_box">
            </ul>
            <div class="tab-content padding tab-content-inline tab-content-bottom">
               <div class="tab-pane active" id="profile">
                  <div class="login-body my_login_body">
                     <div class="myform_cont container" style="padding-bottom:100px;">
                        <form action="<?php echo base_url('corder/orderAction') ?>" method="POST" id="customer-order-form" class="form-horizontal">
                           
                           <table>
                              <tr>
                                 <th>#</th>
                                 <th>Item Name</th>
                                 <th>Item Price</th>
                              </tr>
                              <tbody id="tbody"></tbody>
                           </table>
                           <button type="button"class="form_sub" onclick="addItem();">Add Item</button>
                           
                        
                        <hr style="background:black;padding: 0.5px">
                        <div class="control-group cgstyle ">
                           
                           <div class="span3 sstyle ">
                              <h4><b>Total</b></h4>
                           </div>
                           <div class="span3 sstyle " id="total_amount">
                              <input type="text" value="" name="grand_total" id="grand_total" class="input-large"   readonly>
                           </div>
                           <input type="submit" value="Place Order" id="btn-submitt" class="form_sub">
                        </div>
                        </form>
                        
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</div>
</div>
<div class="clearfix"></div>
</div>
<script type="text/javascript">
   var items = 0;
   function addItem() {
       items++;
   
       var html = "<tr>";
           html += "<td>" + items + "</td>";
           html += "<td><select id='select-product'  name='prod_id[]' onchange='getpricedetails($(this).val(),"+ items + ")' placeholder='Select Product...'    class='operator form-control'><option value=''>Select Product</option><?php foreach ($pro_list as $key => $val) {?><option value='<?php echo $val['prod_id']; ?>'><?php echo $val['prod_name']; ?></option><?php } ?></select></td>";
           html += "<td><input type='text' name='selling_price[]' id='selling_price" + items +"' class='input-large form-control summable' placeholder='Product Price' readonly ></td>";
           html += "<td><button type='button' class='form_sub ' onclick='deleteRow(this);'>Delete</button></td>"
       html += "</tr>";
       
       var row = document.getElementById("tbody").insertRow();
       row.innerHTML = html;
       $(document).on('input', '.summable', sumIt);
       sumIt()  
   }
   
   function deleteRow(button) {
   button.parentElement.parentElement.remove();
    $(document).on('input', '.summable', sumIt);
       sumIt()  
   
   }


   function sumIt() {
  var total = 0, val;
  $('.summable').each(function() {
    val = $(this).val();
    val = isNaN(val) || $.trim(val) === "" ? 0 : parseFloat(val);
    total += val;
  });

  $('#grand_total').val(Math.round(total));
}

   $('#customer-order-form').submit(function(event) {
    event.preventDefault(); 
    
    var formData = new FormData(this);
   
    $.ajax({
      type:'POST',
      url:$(this).attr('action'),
      data:formData,
      cache:false,
      contentType: false, 
      processData: false,
      success:function(res){
        
        if (res.length != 0){
         
         setTimeout(function() {
            
            $('#btn-submitt').removeAttr('disabled');
            $('#btn-submitt').html('Save change'); 
          },500)
    
    
        window.location.href = "<?php base_url(''); ?>corder/cpayment?order_id="+res;
       
   } else {
   
         
        }
   
      }
    });
   });

   function getpricedetails(prod_id='',sel_id) {
    $.ajax({
        type:'POST',
        url:'<?php echo base_url('corder/priceDetails')?>',
        data:{ 'prod_id' : prod_id },
       
      
        cache: false,
        crossDomain: true,
        success: function (res) {
   
        let r  = JSON.parse(res); 
        
        if(r.status){
   
         $.each(r.res, function (index, val) {
         $('#selling_price'+sel_id).val(val.selling_price)
         $(document).on('input', '.summable', sumIt);
       sumIt()  
      });
   
      }
       
     
    }
   })
   }
     
   
   
</script>