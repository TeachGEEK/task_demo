<style>
.signup_error
{
	color:#FF0000; 
	padding-left:15px;
}
</style>
<?php $cust_email = $this->input->get('email');
    
    if(!empty($cust_email))
	{
		
	
   ?>
<section>
   
   
  <div class="img-container porter_partner_home_img">
    <div class="col-md-6 box_side">
        <div class="box box-color box-bordered signin_content">
           <h2 class="heading_kyc">
               <strong class="heading_log">Password Change</strong> 
			   
           </h2>
            <hr>
           </ul>
        <div class="tab-content padding tab-content-inline tab-content-bottom">
          <div class="tab-pane active" id="profile">
           <div class="login-body my_login_body">
             <form action="<?php echo base_url('clogin/updatepasswordAction?cust_email=')?><?php echo $cust_email;?>" method="POST" id="updatepassword-form" class="form-horizontal">
            <div>
                <div class="div_block col-md-12">
                 <label for="cust_password"><b>Enter Your New Password(6 Characters Minimum)</b></label>
                 <input type="password" placeholder="Enter Password" class="form-control password" minlength="6" maxlength="10" name="cust_password" required>
                </div>
                <div class="div_block col-md-12">
                 <label for="cnf_password"><b>Confirm Your New Password</b></label><span id="cnfpassword-error" class="signup_error"></span>
                 <input type="password" placeholder="Enter Confirm Password" class="form-control cnf_password" minlength="6" maxlength="10" name="cnf_password" required>
                </div>
                <div class="clearfix"></div>
				 <!--<input type="hidden" name="cust_email" value="<?php echo $cust_email;?>" id="cust_email">-->
                 <input type="submit" class="form_sub" value="Submit" >
                
             </div>
          </form>
        </div>
      </div>
    </div>
    </div>
    </div>
    </div>
    <div class="col-md-6 box_side .d-sm-none .d-md-block img_side">
      <img src="<?php echo base_url('assets/customer_theme/img/signup.png') ?>"  class="signup_img">
    </div>
    
    
    <div class="clearfix"></div>
  
    </div>
</section>
	<?php } else {?>
	<span>Something went wrong  </span>
	<?php } ?>
<script type="text/javascript"> 
   $(document).ready(function() {
    $('#updatepassword-form').submit(function(event) {
    event.preventDefault(); 
    var formData = new FormData(this);
	$.ajax({
      type:'POST',
      url:$(this).attr('action'),
      data:formData,
      cache:false,
      contentType: false, 
      processData: false,
      success:function(res){
        if(res.trim() == 'true'){
        window.location.href = "<?php echo base_url('clogin');?>";
			toastr.success('Login With Credentials..',{timeOut: 3000});
		} else {

          setTimeout(function() {
            toastr.error('Server error try agains..',{timeOut: 2000});
          },500);
        
        }

      }
    });
});
	
   
   });
   $(".cnf_password").change(function () {    
		var password = $(".password").val();    
		var cnf_password = $(".cnf_password").val();
		if (password == cnf_password) {    
			return true;    
		} else {    
			$("#cnfpassword-error").html("Confirmed Password Does Not Matches To The Entered Password!");
			   
			$(".cnf_password").val('');    
			$(".cnf_password").focus();     
		}       
	});
   
   
</script>