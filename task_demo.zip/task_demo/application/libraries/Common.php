<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Common extends MX_Controller
{
    // use $this->common->insert('tablename',$data);
    public function insert($table, $data){
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }


    // use $this->common->delete('tablename',array('id' => $id));
    public function delete($table,$where){
        $this->db->where($where)->delete($table);
        return 'true';
    }
    
    // get $this->common->getById('tablename',array('id' => $id));
    public function getById($table,$where){
        $this->db->where($where);
        return $this->db->get($table)->row();
    }

   

    
   
    // use $this->common->getData($select='',$table,$where='');
    public function getData($select='',$table,$where='',$order_id='',$group_by='',$limit=''){
        $this->db->select($select);
        if(!empty($where)){
            $this->db->where($where);
        }
        if(!empty($order_id)){
            $this->db->order_by($order_id,'DESC');
        }
        if(!empty($group_by)){
            $this->db->group_by($group_by,'DESC');
        }
        if(!empty($limit)){
            $this->db->limit($limit);
        }
        return $this->db->get($table)->result('array');
    }

   
    
}

?>
