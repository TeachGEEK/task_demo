<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Annu Upadhyay</title>
      <meta http-equiv="content-type" content="text/html;charset=utf-8" />
      <meta name="viewport" content="width=device-width, maximum-scale=1.0, initial-scale=1.0, user-scalable=no, minimum-scale=1.0">
      <meta name="description" content="Annu Upadhyay">
      <meta name="facebook-domain-verification" content="230do0d30w3hz25hc4mqf8f4n4o37q" />
      <link rel="canonical" href="<?php echo base_url(); ?>" />
      <script src="<?php echo base_url('assets/home_page/js/jquery.min.js'); ?>"></script><script src="<?php echo base_url('assets/home_page/js/bootstrap.min.js'); ?>"></script>
      <link rel="stylesheet" href="<?php echo base_url('assets/home_page/css/bootstrap.min.css'); ?>">
     <link href="<?php echo base_url('assets/customer_theme/css/website.css?ver=').time(); ?>" media="screen" rel="stylesheet" />
      <link rel="stylesheet" href="<?php echo base_url('assets/customer_theme/css/custom.css') ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 </head>

    